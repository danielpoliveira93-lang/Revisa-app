# Revisa

Aplicativo web de revisões espaçadas para vestibulares. Hospedagem estática: não usa servidor, banco de dados, login nem serviços pagos.

## Publicar no GitHub Pages
1. Crie um repositório no GitHub (por exemplo, `revisa`).
2. Envie **o conteúdo desta pasta** para a raiz do repositório (`index.html`, `manifest.json`, `icons/`, `.nojekyll`).
3. No repositório, abra **Settings → Pages**, escolha **Deploy from a branch**, branch `main` e pasta `/ (root)`, e salve.
4. Após alguns minutos, o app abrirá em `https://SEU-USUARIO.github.io/revisa/`.

## Adicionar à tela inicial
- **iPhone/iPad (Safari):** botão Compartilhar → **Adicionar à Tela de Início**.
- **Computador (Chrome/Edge):** ícone de instalar na barra de endereço.

## Onde ficam os dados
Cada pessoa tem seus próprios dados, salvos **somente no navegador do próprio aparelho** (`localStorage`). Não há conta nem nuvem.
- Dados do Safari e do app da tela inicial são **separados** no iPhone/iPad. Escolha onde vai usar e, se mudar, leve os dados pelo Backup.
- Limpar os dados do site apaga tudo. Faça backup com frequência (Conteúdos → Backup).
- Para trocar de aparelho: exporte o backup no aparelho antigo e importe no novo.
